# Offene Lücken nach v16.9

## P0 – Integration
Die Module sind noch nicht in einem gemeinsamen Projektstand zusammengeführt.

Fehlt:
- ein gemeinsamer Launcher
- ein gemeinsames Datenmodell
- zentrale Konfiguration
- gemeinsame Runtime
- einheitlicher Event Bus
- einheitliches Logging
- einheitliche Tests

## P0 – Produktive Datenbank
Fehlt:
- PostgreSQL
- pgvector
- Alembic
- Connection Pooling
- Migrationsstrategie
- Backup/Restore produktiv

## P0 – Sicherheit
Fehlt:
- echte Secret-Verschlüsselung
- DPAPI/Keyring
- Rollenmodell
- Audit Reports
- DSGVO Export/Löschung
- Approval UI

## P1 – echte Connectoren
Fehlt:
- echter OAuth Flow
- Gmail API
- Google Calendar API
- Google Drive API
- GitHub API
- Paperless API
- Obsidian Watcher

## P1 – echte Intelligenz
Fehlt:
- LLM Provider Layer
- Tool Calling
- echte Embeddings
- Reranker
- Agent Planning
- Result Validation
- Memory Compression

## P1 – Desktop produktiv
Fehlt:
- Docking Layout
- System Tray
- Settings vollständig
- Agent Control Center
- Graph View
- RAG Chat
- Connector UI
- Approval Inbox

## P2 – Mobile/Voice produktiv
Fehlt:
- native App oder PWA
- echte Push Notifications
- Faster Whisper
- Piper/ElevenLabs
- OpenWakeWord/Porcupine
- Mikrofonstreaming
