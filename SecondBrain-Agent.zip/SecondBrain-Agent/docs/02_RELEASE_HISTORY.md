# Release-Historie

## v14.0 – Persistent Personal AGI
- Persistent Personal AGI Runtime
- Governance Policy
- Observe → Think → Plan → Act → Verify → Learn
- Proactive Assistant
- Self Optimizer

## v15.0 – Production Core
- Service Foundation
- Watchdog
- Secrets Vault Scaffold
- Audit Trail
- Approval Workflow
- Backup / Restore Plan

## v15.1 – Service Runtime
- Service Runner
- JSON Logs
- Health / Ready / Metrics
- HTTP Health Server
- pywin32 / NSSM Scaffold

## v15.2 – Installer & Update
- Release Manifest
- Config Validator
- Portable Installer Plan
- Backup before Update
- Rollback Plan

## v16.0 – PySide6 Desktop App
- Main Window
- Dashboard
- Chat UI
- Knowledge Explorer
- Task Board
- Notifications
- Settings

## v16.1 – Database Architecture
- SQLite Persistence
- PostgreSQL-ready Schema
- Memories, Tasks, Documents, Events, Automations, Embeddings
- Migration Runner

## v16.2 – Connector Framework
- Gmail, Google Calendar, Google Drive, GitHub, Obsidian, Paperless Registry
- Delta Cursor
- Sync Runs
- Connector Items
- Dead Letter Queue

## v16.3 – Document Understanding
- TXT/Markdown/EML Ingestion
- DOCX XML Reader
- XLSX/PPTX Scaffold
- PDF Stub
- Chunking
- Citations
- Entity Extraction

## v16.4 – Multi-Agent Runtime
- Supervisor
- Planner
- Research
- Execution
- Review
- Memory
- Improvement Agent

## v16.5 – Knowledge Graph
- Nodes / Edges
- Neighbors
- Shortest Path
- Communities
- Timeline
- Neo4j Cypher Export

## v16.6 – Long-Term Memory
- Episodic Memory
- Semantic Memory
- Procedural Memory
- Memory Links
- Consolidation
- Recall

## v16.7 – Hybrid RAG
- BM25-like Search
- Pseudo Embeddings
- Hybrid Ranking
- Reranking
- Citation Engine
- Context Compression

## v16.8 – Realtime Voice
- Voice Sessions
- Wake Word Stub
- STT/TTS Adapter
- Intent Parser
- Approval Boundary
- Interrupts

## v16.9 – Mobile Companion
- Device Pairing
- Offline Capture
- Voice Notes
- Camera OCR Scaffold
- Push Outbox
- Mobile Widgets
- Sync Runs
- Remote Sessions
