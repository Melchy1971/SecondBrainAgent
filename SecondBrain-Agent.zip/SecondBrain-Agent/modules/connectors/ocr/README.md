# ocr

OCR-Pipeline vorbereitet.
